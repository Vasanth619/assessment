@extends('admin.app')


@section('content')

@endsection


