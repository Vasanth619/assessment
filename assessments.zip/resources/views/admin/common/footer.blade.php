
<div class="footer">
  
  <div class="footer__bottom">
    <div class="row">
      <div class="col-md-4">
        
      </div>
      <div class="col-md-8">
        <div class="footer__company">
          <img class="footer__company-logo" src="{{ asset('components/dummy-assets/common/img/mediatec.png') }}"
               title="Mediatec Software">
          <span>
            © 2018 <a href="#" target="_blank">Clorida Technologies</a>
            <br>
            All rights reserved
          </span>
        </div>
      </div>
    </div>
  </div>
  <a href="javascript: void(0);" class="utils__scroll-top" onclick="$('body, html').animate({'scrollTop': 0}, 500)"><i
    class="icmn-arrow-up"></i></a>
</div>