<div class="menu-right">
    <div class="menu-right__inner">
        <div class="menu-right__header">
            <span class="fa fa-times pull-right menu-right__action--menu-toggle"><!-- --></span>
            Theme Settings
        </div>
        <div class="menu-right__content">
            <div class="menu-right__descr">
                This module "block-menu-right" gives possibility to construct custom blocks with any widgets, components and elements inside, like this theme settings
            </div>
            <div class="menu-right__label">
                Theme Style
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value=""> Dark
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value="theme--light"> Light
                        </label>
                    </div>
                </div>
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value="theme--green"> Green
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value="theme--blue"> Blue
                        </label>
                    </div>
                </div>
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value="theme--red"> Red
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-theme" value="theme--orange"> Orange
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Boxed Layout
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-boxed" value="config--boxed"> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-boxed" value=""> Off
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Fixed Top Bar
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-topbar" value=""> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-topbar" value="config--unfixed"> Off
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Borderless Cards
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-borderLess" value="config--borderLess"> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-borderLess" value=""> Off
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Colorful Menu
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-colorful" value="menu-left--colorful"> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-colorful" value=""> Off
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Menu Shadow
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-shadow" value="menu-left--shadow"> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-shadow" value=""> Off
                        </label>
                    </div>
                </div>
            </div>
            <div class="menu-right__label">
                Squared Corners
            </div>
            <div class="menu-right__setting menu-right--example-option">
                <div class="btn-group btn-group-justified" data-toggle="buttons">
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-corners" value="config--squared-corners"> On
                        </label>
                    </div>
                    <div class="btn-group">
                        <label class="btn btn-default">
                            <input type="radio" name="options-corners" value=""> Off
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>