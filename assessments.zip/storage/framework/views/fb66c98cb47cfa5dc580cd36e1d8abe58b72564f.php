<?php $__env->startSection('content'); ?>
   
	<div class="utils__content">
      <section class="card">
		<div class="row">
			<div class="col-md-3">
				 <div class="card-body">
				<form action="<?php echo e(url('admin/store_question')); ?>" method="post">
		     	 <?php echo csrf_field(); ?>

		     	 <div class="form-group"> 
		     	 <label class="form-label">Category</label>	
				     <select class="form-control" name="question_category" id="main_category">
                        <option>Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
				 </div>

					<div class="form-group">
					<label class="form-label">Sucategory</label>
	                    <select class="form-control" name="question_subcategory" id="question_subcategory">
	                    	<option>Select Subcategory</option>
	                    </select>
                     </div>
					
			         <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="question_status" class="form-control" data-validation="[NOTEMPTY]" required>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                            
                            </select>
                        </div>

                  </div>    
			</div>
			<div class="col-md-9">
				
		    <div class="card-header">
		        <span class="utils__title">
		            <strong>Question</strong>
		        </span>
		    </div>
		    <div class="card-body">
		     
		     
		         <div class="form-group"> 
		             <div class="input-append input-group"> 
		               <textarea  class="form-control" placeholder="" name="question_name"></textarea>
		             </div>
		         </div>

				<div class="row">
			         <div class="form-group col-md-10"> 
			             <div class="input-append input-group"> 

			             	    <label class="utils__control utils__control--radio">
			                        <input type="radio" name="correct_answer[]" value="1">
			                        <span class="utils__control__indicator"></span>
			                    </label>
			               <textarea  class="form-control" placeholder="" name="answer[]"></textarea>
			             </div>
			         </div>
					<div class="col-md-1">
			         <button type="button" class="btn btn-icon btn-outline-primary add_newchoice"><i class="fa fa-plus" aria-hidden="true"></i></button>
			        </div> 
				</div>	
				

				<div id="append_template"></div>

				<div class="float-right"> 
				
					<button class="btn btn-primary ladda-button mr-2 mb-2" type="submit" >Save</button>
					
			   </div>

			  </form> 
		    </div>
		  
			</div>
		</div>

		</section>

		</div>


                <div class="row choiceTemplate" style="display: none" id="choice_template">
			         <div class="form-group col-md-10"> 
			             <div class="input-append input-group"> 

			             	    <label class="utils__control utils__control--radio">
			                        <input type="radio" name="correct_answer[]" value="1">
			                        <span class="utils__control__indicator"></span>
			                    </label>
			               <textarea  class="form-control" placeholder="" name="answer[]"></textarea>
			             </div>
			         </div>
					<div class="col-md-1">
			         <button type="button" class="btn btn-icon btn-outline-primary remove_choice"><i class="fa fa-minus" aria-hidden="true"></i></button>
			        </div> 
				</div>


<script>
    $('.summernote').summernote({
       	    placeholder: 'write here...',
		      toolbar: [
		    
		    ['para', ['style', 'ul', 'ol', 'paragraph']],
		    ['fontsize', ['fontsize']],
		    ['style', ['bold', 'italic', 'underline', 'clear']],
		    ['font', ['strikethrough', 'superscript', 'subscript']],
		    ['height', ['height']],
		    ['insert', ['link', 'picture', 'hr']],
		    ['misc', ['table','undo', 'redo', 'print', 'help', 'fullscreen']]
		  ],
      });
    //get sub category  
	$(function() {
		$('#main_category').change(function() {
			$.ajax({
				url: '<?php echo e(url("/admin/get_subcategory")); ?>',
				method: 'get',
				data: {
					category: $(this).val(),
					_token: '<?php echo e(csrf_token()); ?>'
				},
				dataType: 'html',
				success: function(response) {
					$('#question_subcategory').empty().html(response);
				}
			});
		});

		$('body').on('click', '.add_newchoice', function() {
			var template = $('#choice_template').clone();
			    template.removeAttr('id');
			$('#append_template').before(template.removeAttr('style'));
		});

		$('body').on('click', '.remove_choice', function() {
			var template = $(this).parents('.choiceTemplate');
			template.remove();
		});

	});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>