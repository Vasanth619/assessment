<?php $__env->startSection('content'); ?>

<section class="card">
    <div class="card-header">
        <span class="utils__title">

            <strong>Total Questions</strong>
                    <select class="selectpicker">
                        <option>Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <a href="<?php echo e(url('admin/new_question')); ?>"><button type="button" class="btn btn-icon btn-outline-primary mr-2 mb-2 float-right" id="add_category" data-toggle="modal" data-target="#add_newcategory"><i class="icmn-rocket" aria-hidden="true"></i></button></a>
        </span>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
               
                <div class="table-responsive mb-5">
                    <table class="table table-hover nowrap editable-table" id="example1" style="cursor: pointer;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Question</th>
                            <th>Category</th>
                            <th>Subcategory</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                           $i = 1; 
                        ?>

                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <tr>
                            <td tabindex="1"><?php echo e($i++); ?></td>
                            <td tabindex="1"><?php echo e($question->question); ?></td>
                            <td tabindex="1"><?php echo e($question->cat_name); ?></td>
                            <td tabindex="1"><?php echo e($question->subcat_name); ?></td>
                            <td tabindex="1"><?php echo e(($question->status == 1)? "Active" : "Inactive"); ?></td>
                            <td tabindex="1">Edit / Delete</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                <input style="position: absolute; display: none;"></div>
            </div>
        </div>
        
    </div>
</section>


<script>
  (function($) {
    "use strict";
    $(function () {

      $('#example1').DataTable({
        responsive: true
      });

    });
  })(jQuery)
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>