<?php $__env->startSection('content'); ?>

<section class="card">
    <div class="card-header">
        <span class="utils__title">
            <strong>Sub Categories</strong>
            <button type="button" class="btn btn-icon btn-outline-primary mr-2 mb-2 float-right" id="add_category" data-toggle="modal" data-target="#add_new_subcategory"><i class="icmn-rocket" aria-hidden="true"></i></button>
        </span>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <!-- <h5 class="text-black"><strong>Basic Editable Table</strong></h5>
                <p class="text-muted">Element: read <a href="http://mindmup.github.io/editable-table/" target="_blank">official documentation<small><i class="icmn-link ml-1"></i></small></a></p> -->
                
                <div class="modal fade" id="add_new_subcategory" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">New Subcategory</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('/admin/add_question_sub_category')); ?>" method="post" id="new_sub_category">
                                  <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label class="form-label">Main Category</label>
                                    <select name="category_status" class="form-control" data-validation="[NOTEMPTY]" >
                                    <option>Select</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                     <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    </select>
                                </div>
                                

                                <div class="form-group">
                                    <label class="form-label">Category Name</label>
                                    <input name="sub_category_name" type="text" class="form-control" data-validation="[NOTEMPTY]">
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select name="sub_category_status" class="form-control" data-validation="[NOTEMPTY]">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                    
                                    </select>
                                </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>


                <div class="table-responsive mb-5">
                    <table class="table table-hover nowrap editable-table" id="example1" style="cursor: pointer;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Category Name</th>
                            <th>Main Category Name</th>
                            <th>Created Date</th>
                            <th>Updated Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        
                        <tbody>
						   <?php
						      $i = 1;
						   ?>


                           <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                        	<tr>
                        		<td><?php echo e($i++); ?></td>
                        		<td><?php echo e($subcategory->name); ?></td>
                        		<td><?php echo e($subcategory->category_name); ?></td>
                        		<td><?php echo e($subcategory->created_at); ?></td>
                        		<td><?php echo e($subcategory->updated_at); ?></td>
                        		<td><?php echo e($subcategory->status); ?></td>
                        		<td><a edit-id="<?php echo e($subcategory->id); ?>" class="edit_subcategory">Edit</a> / <a delete-id="<?php echo e($subcategory->id); ?>" class="delete_subcategory">Delete</a></td>
                        	</tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
                        </tbody>
                        
                    </table>
                <input style="position: absolute; display: none;"></div>
            </div>
        </div>
        
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>

<script>
  (function($) {
    "use strict";
    $(function () {

      $('#example1').DataTable({
        responsive: true
      });


       $('#new_category').validate({
        submit: {
          settings: {
            inputContainer: '.form-group',
            errorListClass: 'form-control-error',
            errorClass: 'has-danger'
          }
        }
      });


    });
  })(jQuery)


   
   $(function() {
   	  $('#new_sub_category').submit(function() {
   	  	  $('#new_sub_category').validate();
   	  }); 
   });


</script>


<script>
 
 $('body').on('click', '.delete_subcategory', function() {
 	var delete_category = $(this).attr('delete-id');
	swal({
		title: "Are you sure?",
		type: "warning",
		showCancelButton: true,
		confirmButtonClass: "btn-danger",
		confirmButtonText: "Yes, delete it!",
		cancelButtonText: "No, cancel plx!",
		closeOnConfirm: false,
		closeOnCancel: false
	},
	function(isConfirm) {
		if (isConfirm) {
			$.ajax({
				url: '<?php echo e(url("/admin/delete_subcategory")); ?>',
				method: 'post',
				data:{
					'_token': "<?php echo e(csrf_token()); ?>",
					'data_id':  delete_category,
					
				},
				dataType: 'json',
				success: function(response) {
					if(response.status == 1) {
						swal(response.message ,"success");

						location.reload();
					}
					else if(response.status == 0) {
						swal(response.message ,"error");

						location.reload();
					}
				}
			});
	} else {
		
	}
	});

});

</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>